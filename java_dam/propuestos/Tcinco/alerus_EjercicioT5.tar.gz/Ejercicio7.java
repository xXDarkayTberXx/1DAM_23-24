package alerus.ejercicios.propuestos.Tcinco;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(" ");
		System.out.println("*** Tabla del 1 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(1 + " x " + i + " = " + (1 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 2 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(2 + " x " + i + " = " + (2 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 3 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(3 + " x " + i + " = " + (3 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 4 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(4 + " x " + i + " = " + (4 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 5 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(5 + " x " + i + " = " + (5 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 6 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(6 + " x " + i + " = " + (6 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 7 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(7 + " x " + i + " = " + (7 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 8 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(8 + " x " + i + " = " + (8 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 9 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(9 + " x " + i + " = " + (9 * i) );
		}

		System.out.println(" ");
		System.out.println("*** Tabla del 10 ***");
		System.out.println(" ");

		for (int i = 0; i <= 10; i++) {
			System.out.println(10 + " x " + i + " = " + (10 * i) );

		}
	}
}
