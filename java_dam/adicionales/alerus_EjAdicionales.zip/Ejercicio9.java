package alerus.ejercicios.adicionales;

import java.util.Scanner;

public class Ejercicio9 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Dime un número: ");
		int n = sc.nextInt();
		int c = 1;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				if (c == n+1) {
					break;
				}
				System.out.print(c + " ");
				c = c + 1;
			}
			System.out.println();

		}



	}

}
