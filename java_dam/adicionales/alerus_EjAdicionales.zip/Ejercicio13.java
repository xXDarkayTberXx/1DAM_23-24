package alerus.ejercicios.adicionales;

import java.util.Scanner;

public class Ejercicio13 {

	public static void main(String[] args) throws InterruptedException {

		Scanner sc = new Scanner(System.in);

		int segundos = 0;
		int minutos = 0;
		int horas = 0;

		while (horas < 24) {

			Thread.sleep(1000);

			segundos +=1;

			if (segundos == 60) {

				minutos +=1;
				segundos = 0;

			}
			if (minutos == 60) {

				horas +=1;
				minutos = 0;

			}

			String tiempoFormateado = String.format("%02d:%02d:%02d", horas, minutos, segundos);
			System.out.println(tiempoFormateado);
		}

	}

}
